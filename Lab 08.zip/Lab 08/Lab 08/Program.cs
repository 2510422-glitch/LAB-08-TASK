﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // 1. Store the four subject names in a string array
        string[] subjects = { "Mathematics", "Science", "English", "History" };

        // 2. Use a Dictionary<string, List<int>> for student name -> list of marks
        Dictionary<string, List<int>> gradebook = new Dictionary<string, List<int>>();

        Console.WriteLine("--- Gradebook Entry System ---");
        int minimumStudents = 3;
        int studentCount = 0;

        // 3. Add at least 3 students
        while (studentCount < minimumStudents)
        {
            Console.Write($"\nEnter the name for Student #{studentCount + 1}: ");
            string name = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(name))
            {
                Console.WriteLine("Name cannot be empty. Please try again.");
                continue;
            }

            if (gradebook.ContainsKey(name))
            {
                Console.WriteLine("This student already exists. Please enter a unique name.");
                continue;
            }

            List<int> marks = new List<int>();

            // Loop over the subject array and read one mark per subject
            foreach (string subject in subjects)
            {
                int mark;
                while (true)
                {
                    Console.Write($"  Enter mark for {subject} (0-100): ");
                    if (int.TryParse(Console.ReadLine(), out mark) && mark >= 0 && mark <= 100)
                    {
                        break;
                    }
                    Console.WriteLine("  Invalid input! Please enter an integer between 0 and 100.");
                }
                marks.Add(mark);
            }

            // Save to dictionary
            gradebook.Add(name, marks);
            studentCount++;
        }

        // 4. Show each student's marks next to the subject names, together with their average
        Console.WriteLine("\n=============================================");
        Console.WriteLine("--- Student Performance Summary ---");
        Console.WriteLine("=============================================");

        string topperName = "";
        double highestAverage = -1;

        foreach (var entry in gradebook)
        {
            string studentName = entry.Key;
            List<int> studentMarks = entry.Value;
            double average = studentMarks.Average();

            Console.WriteLine($"\nStudent: {studentName}");
            for (int i = 0; i < subjects.Length; i++)
            {
                Console.WriteLine($"  {subjects[i]}: {studentMarks[i]}");
            }
            Console.WriteLine($"  Average Mark: {average:F2}");

            // Track class topper
            if (average > highestAverage)
            {
                highestAverage = average;
                topperName = studentName;
            }
        }

        // 5. Show the class topper (highest average)
        Console.WriteLine("\n=============================================");
        Console.WriteLine($"🏆 Class Topper: {topperName} with an average of {highestAverage:F2}");
        Console.WriteLine("=============================================");

        // 6. Let the user search for a student by name
        Console.WriteLine("\n--- Student Search ---");
        while (true)
        {
            Console.Write("\nEnter a student name to search (or press Enter to exit): ");
            string searchName = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(searchName))
            {
                break;
            }

            // Show a message if the name is not found
            if (gradebook.TryGetValue(searchName, out List<int> foundMarks))
            {
                Console.WriteLine($"\nMatch found for '{searchName}':");
                for (int i = 0; i < subjects.Length; i++)
                {
                    Console.WriteLine($"  {subjects[i]}: {foundMarks[i]}");
                }
                Console.WriteLine($"  Overall Average: {foundMarks.Average():F2}");
            }
            else
            {
                Console.WriteLine($"❌ Student '{searchName}' was not found in the gradebook.");
            }
        }

        Console.WriteLine("\nThank you for using the Gradebook system!");
    }
}
