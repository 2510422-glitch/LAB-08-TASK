﻿using System;

// 1. Create custom exceptions
public class InvalidAmountException : Exception
{
    public InvalidAmountException(string message) : base(message) { }
}

public class InsufficientBalanceException : Exception
{
    public InsufficientBalanceException(string message) : base(message) { }
}

// 2. Create the Wallet class
public class Wallet
{
    public decimal Balance { get; private set; }

    public Wallet(decimal initialBalance)
    {
        Balance = initialBalance;
    }

    public void Withdraw(decimal amount)
    {
        // For zero or negative amounts
        if (amount <= 0)
        {
            throw new InvalidAmountException("Withdrawal amount must be greater than zero.");
        }

        // When the amount is more than the balance
        if (amount > Balance)
        {
            throw new InsufficientBalanceException($"Insufficient funds. You requested {amount:C}, but your balance is only {Balance:C}.");
        }

        // Deduct the amount if valid
        Balance -= amount;
        Console.WriteLine($"✅ Successfully withdrew {amount:C}!");
    }
}

class Program
{
    static void Main()
    {
        // Initialize wallet with some starting money
        Wallet myWallet = new Wallet(500.00m);

        Console.WriteLine("--- Welcome to your Digital Wallet ---");
        Console.WriteLine($"Starting Balance: {myWallet.Balance:C}");
        Console.WriteLine("(Type '0' at any time to exit)");

        while (true)
        {
            Console.Write("\nEnter the amount to withdraw: ");
            string input = Console.ReadLine()?.Trim();

            if (input == "0")
            {
                break;
            }

            try
            {
                // This can throw a FormatException if text is entered instead of a number
                decimal amount = decimal.Parse(input);

                myWallet.Withdraw(amount);
            }
            // 3. Use try-catch to handle specific errors
            catch (FormatException)
            {
                Console.WriteLine("❌ Error: Invalid input. Please enter a valid number (numbers only, no letters).");
            }
            catch (InvalidAmountException ex)
            {
                Console.WriteLine($"❌ Transaction Denied: {ex.Message}");
            }
            catch (InsufficientBalanceException ex)
            {
                Console.WriteLine($"❌ Transaction Denied: {ex.Message}");
            }
            catch (Exception ex) // General Exception caught last
            {
                Console.WriteLine($"❌ An unexpected error occurred: {ex.Message}");
            }
            // 4. Use a finally block to print the balance after every attempt
            finally
            {
                Console.WriteLine($"   [Current Balance: {myWallet.Balance:C}]");
            }
        }

        Console.WriteLine("\nThank you for using the Digital Wallet. Goodbye!");
    }
}

