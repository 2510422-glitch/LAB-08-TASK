﻿using System;
using System.Collections.Generic;

class Program
{
   
    public delegate double DiscountRule(double price);

    
    private static List<string> purchaseLog = new List<string>();

    static void Main()
    {
        
        Action<string> receiptLogger = PrintToConsole;
        receiptLogger += LogToList;

        Console.WriteLine("--- Online Store Checkout ---");

        while (true)
        {
            Console.Write("\nEnter item base price (or type '0' to finish shopping): ");
            if (!double.TryParse(Console.ReadLine(), out double price) || price < 0)
            {
                Console.WriteLine("Invalid price. Please enter a positive number.");
                continue;
            }

            if (price == 0) break;

           
            Console.WriteLine("\nSelect a Discount Rule:");
            Console.WriteLine("1. No Discount");
            Console.WriteLine("2. Student Discount (10% off)");
            Console.WriteLine("3. Festival Discount (25% off)");
            Console.Write("Enter your choice (1-3): ");
            string choice = Console.ReadLine();

            DiscountRule selectedRule;

           
            switch (choice)
            {
                case "1":
                    selectedRule = NoDiscount;
                    break;
                case "2":
                    selectedRule = StudentDiscount;
                    break;
                case "3":
                    selectedRule = FestivalDiscount;
                    break;
                default:
                    Console.WriteLine("Invalid selection. Defaulting to No Discount.");
                    selectedRule = NoDiscount;
                    break;
            }

           
            ApplyDiscount(price, selectedRule, receiptLogger);
        }

       
       
        Console.WriteLine("--- Complete Store Purchase Log ---");
       

        if (purchaseLog.Count == 0)
        {
            Console.WriteLine("No transactions were completed today.");
        }
        else
        {
            foreach (string logEntry in purchaseLog)
            {
                Console.WriteLine(logEntry);
            }
        }

        Console.WriteLine("\nThank you for shopping with us!");
    }

   
    static double NoDiscount(double price) => price;

    static double StudentDiscount(double price) => price * 0.90; // 10% off

    static double FestivalDiscount(double price) => price * 0.75; // 25% off

  
    static void ApplyDiscount(double price, DiscountRule rule, Action<string> logger)
    {
        double finalPrice = rule(price);
        string transactionDetails = $"Processed Order: Base Price: {price:C} | Final Price: {finalPrice:C} (Rule: {rule.Method.Name})";

        
        logger(transactionDetails);
    }

   
    static void PrintToConsole(string message)
    {
        Console.WriteLine($"\n[RECEIPT] {message}");
    }

    static void LogToList(string message)
    {
        
        purchaseLog.Add($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}");
    }
}

