﻿using System;

class Program
{
    
    public delegate void VideoUploadedEventHandler(string title);

   
    public class Channel
    {
      
        public event VideoUploadedEventHandler VideoUploaded;

        public void Upload(string title)
        {
            Console.WriteLine($"\n[Channel] Uploading new video: \"{title}\"...");

          
            VideoUploaded?.Invoke(title);
        }
    }

    
    public class Ali
    {
        public void OnVideoNotification(string videoTitle)
        {
            Console.WriteLine($"🔔 Ali notified: 'Wow! I need to watch \"{videoTitle}\" right away!'");
        }
    }

    public class Sara
    {
        public void OnVideoNotification(string videoTitle)
        {
            Console.WriteLine($"🔔 Sara notified: 'Adding \"{videoTitle}\" to my Watch Later list.'");
        }
    }

    static void Main()
    {
        Channel myChannel = new Channel();
        Ali userAli = new Ali();
        Sara userSara = new Sara();

        
        myChannel.VideoUploaded += userAli.OnVideoNotification;
        myChannel.VideoUploaded += userSara.OnVideoNotification;

       
        myChannel.Upload("C# Events Tutorial for Beginners");

        
        Console.WriteLine("\n--- Sara unsubscribes from the channel ---");
        myChannel.VideoUploaded -= userSara.OnVideoNotification;

       
        myChannel.Upload("Advanced C# Programming Tips");

        Console.WriteLine("\nSimulation completed successfully.");
    }
}

