﻿using System;
using System.Collections.Generic;


public class InvalidBidException : Exception
{
    public InvalidBidException(string message) : base(message) { }
}


public class BidEventArgs : EventArgs
{
    public string ItemName { get; }
    public string BidderName { get; }
    public decimal Amount { get; }

    public BidEventArgs(string itemName, string bidderName, decimal amount)
    {
        ItemName = itemName;
        BidderName = bidderName;
        Amount = amount;
    }
}


public class Auction
{
    public string ItemName { get; }
    public decimal HighestBid { get; private set; }
    public string CurrentLeader { get; private set; }

    
    public event EventHandler<BidEventArgs> BidPlaced;

    public Auction(string itemName, decimal startingPrice)
    {
        ItemName = itemName;
        HighestBid = startingPrice;
        CurrentLeader = "No Bids Yet";
    }

    public void PlaceBid(string bidderName, decimal amount)
    {
        Console.WriteLine($"\n[Auction] {bidderName} attempts to bid {amount:C} on {ItemName}...");

       
        if (amount <= HighestBid)
        {
            throw new InvalidBidException($"Bid of {amount:C} rejected. It must be higher than the current highest bid of {HighestBid:C}.");
        }

        HighestBid = amount;
        CurrentLeader = bidderName;

        
        OnBidPlaced(new BidEventArgs(ItemName, bidderName, amount));
    }

   
    protected virtual void OnBidPlaced(BidEventArgs e)
    {
        BidPlaced?.Invoke(this, e);
    }
}


public class ScreenDisplay
{
    public void OnBidPlacedNotification(object sender, BidEventArgs e)
    {
        Console.WriteLine($"🖥️  [SCREEN] New highest bid! {e.BidderName} bid {e.Amount:C} on '{e.ItemName}'.");
    }
}


public class SellerNotifier
{
    public List<string> PerformanceMessages { get; } = new List<string>();

    public void OnBidPlacedNotification(object sender, BidEventArgs e)
    {
        string logMsg = $"Notification sent to Seller: {e.BidderName} holds the lead at {e.Amount:C} on '{e.ItemName}'";
        PerformanceMessages.Add(logMsg);
    }
}

class Program
{
    static void Main()
    {
       
        Auction vintageCameraAuction = new Auction("Vintage Leica Camera", 100.00m);

        ScreenDisplay liveMonitor = new ScreenDisplay();
        SellerNotifier backendLog = new SellerNotifier();

        
        vintageCameraAuction.BidPlaced += liveMonitor.OnBidPlacedNotification;
        vintageCameraAuction.BidPlaced += backendLog.OnBidPlacedNotification;

        Console.WriteLine($"=== Auction Started for '{vintageCameraAuction.ItemName}' (Reserve: {vintageCameraAuction.HighestBid:C}) ===");

        try
        {
            vintageCameraAuction.PlaceBid("Ali", 150.00m);
        }
        catch (InvalidBidException ex) { Console.WriteLine($"❌ Error: {ex.Message}"); }

       
        try
        {
            vintageCameraAuction.PlaceBid("Sara", 130.00m);
        }
        catch (InvalidBidException ex)
        {
            Console.WriteLine($"❌ Error: {ex.Message}");
        }

        
        try
        {
            vintageCameraAuction.PlaceBid("Zain", 200.00m);
        }
        catch (InvalidBidException ex) { Console.WriteLine($"❌ Error: {ex.Message}"); }

       
        Console.WriteLine("\n--- Disconnecting ScreenDisplay from Live Events ---");
        vintageCameraAuction.BidPlaced -= liveMonitor.OnBidPlacedNotification;

        
        try
        {
            vintageCameraAuction.PlaceBid("Sara", 250.00m);
        }
        catch (InvalidBidException ex) { Console.WriteLine($"❌ Error: {ex.Message}"); }

      
        Console.WriteLine("\n=======================================================");
        Console.WriteLine("--- End of Auction: Seller Notification Logs ---");
        Console.WriteLine("=======================================================");
        foreach (string message in backendLog.PerformanceMessages)
        {
            Console.WriteLine(message);
        }
    }
}
